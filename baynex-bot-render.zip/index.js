require('dotenv').config();
const fetch = require('node-fetch');
const WebSocket = require('ws');
const express = require('express');
const app = express();

app.use(express.json());

const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`;

function sendTelegramMessage(text) {
  fetch(TELEGRAM_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: process.env.TELEGRAM_CHAT_ID,
      text
    })
  });
}

function getBalance() {
  const ws = new WebSocket("wss://ws.deriv.com/websockets/v3");

  ws.onopen = () => {
    ws.send(JSON.stringify({
      authorize: process.env.DERIV_API_TOKEN
    }));
  };

  ws.onmessage = (msg) => {
    const data = JSON.parse(msg.data);
    if (data.msg_type === "authorize") {
      ws.send(JSON.stringify({ balance: 1 }));
    }
    if (data.msg_type === "balance") {
      sendTelegramMessage(`💰 Balance: ${data.balance.balance} ${data.balance.currency}`);
      ws.close();
    }
  };
}

app.post("/webhook", (req, res) => {
  const text = req.body.message?.text;
  if (text === "/start") {
    sendTelegramMessage("🤖 B.A.Y.N.E.X bot started!");
  } else if (text === "/balance") {
    getBalance();
  } else if (text === "/help") {
    sendTelegramMessage("/start - Start bot\n/balance - Check balance\n/help - Help");
  }
  res.sendStatus(200);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
