const WebSocket = require('ws');
const fetch = require('node-fetch');
require('dotenv').config();

const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`;

async function sendTelegramMessage(text) {
  try {
    const response = await fetch(TELEGRAM_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: process.env.TELEGRAM_CHAT_ID,
        text
      })
    });
    if (!response.ok) {
      console.error('Telegram error:', await response.text());
    }
  } catch (error) {
    console.error('Telegram fetch failed:', error);
  }
}

async function checkBalance() {
  const ws = new WebSocket('wss://ws.deriv.com/websockets/v3');

  ws.onopen = () => {
    ws.send(JSON.stringify({
      authorize: process.env.DERIV_API_TOKEN
    }));
  };

  ws.onmessage = (msg) => {
    const data = JSON.parse(msg.data);

    if (data.msg_type === 'authorize') {
      ws.send(JSON.stringify({ balance: 1 }));
    } else if (data.msg_type === 'balance') {
      const balance = data.balance.balance;
      const currency = data.balance.currency;
      sendTelegramMessage(`💰 Balance: ${balance} ${currency}`);
      ws.close();
    }
  };

  ws.onerror = (err) => {
    console.error('WebSocket error:', err);
    sendTelegramMessage('❌ WebSocket error.');
  };
}

const express = require('express');
const app = express();
app.use(express.json());

app.post('/webhook', (req, res) => {
  const message = req.body.message.text;
  if (message === '/balance') checkBalance();
  else if (message === '/start') sendTelegramMessage('🤖 B.A.Y.N.E.X is online!');
  else if (message === '/help') sendTelegramMessage('/balance - get balance\n/start - wake the bot');
  res.sendStatus(200);
});

app.listen(3000, () => console.log('Bot server running'));